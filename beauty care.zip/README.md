
  # Replicate Exact Design

  This is a code bundle for Replicate Exact Design. The original project is available at https://www.figma.com/design/5x3H0sjiYFFcW5sO1kbFYI/Replicate-Exact-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  